--
-- PostgreSQL database dump
--

\restrict ogVEg6vXJndfe8Owwbz0wM6r844esHe48MF6r4hIJkDVDB1Gy9enbuB4m0up7GV

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: band; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.band AS ENUM (
    'R',
    'O',
    'Y',
    'G',
    'U'
);


--
-- Name: incident_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.incident_status AS ENUM (
    'RECEIVED',
    'ACKNOWLEDGED',
    'DISPATCHED',
    'EN_ROUTE',
    'ON_SCENE',
    'TRANSPORTING',
    'AT_HOSPITAL',
    'CLOSED',
    'CANCELLED',
    'MERGED'
);


--
-- Name: audit_events_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_events_immutable() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
begin
  raise exception 'audit_events is append-only (% refused)', tg_op;
end $$;


--
-- Name: current_hospital_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.current_hospital_id() RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
  select hospital_id from public.profiles where user_id = auth.uid()
$$;


--
-- Name: current_role_name(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.current_role_name() RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
  select role from public.profiles where user_id = auth.uid()
$$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
begin
  new.updated_at := now();
  return new;
end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assessments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_id text NOT NULL,
    version integer NOT NULL,
    band public.band NOT NULL,
    nsi smallint NOT NULL,
    conf text NOT NULL,
    reasons jsonb NOT NULL,
    inputs jsonb NOT NULL,
    engine_version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT assessments_conf_check CHECK ((conf = ANY (ARRAY['H'::text, 'M'::text, 'L'::text])))
);


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id bigint NOT NULL,
    incident_id text,
    actor text NOT NULL,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    reason text,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: eta_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eta_cache (
    origin_key text NOT NULL,
    hospital_id text NOT NULL,
    minutes real NOT NULL,
    km real,
    source text NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT eta_cache_source_check CHECK ((source = ANY (ARRAY['osrm'::text, 'ors'::text, 'haversine'::text])))
);


--
-- Name: hospital_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hospital_status (
    hospital_id text NOT NULL,
    status text NOT NULL,
    set_by text NOT NULL,
    set_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hospital_status_status_check CHECK ((status = ANY (ARRAY['OK'::text, 'BUSY'::text, 'SATURATED'::text])))
);


--
-- Name: hospitals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hospitals (
    id text NOT NULL,
    name text NOT NULL,
    level text NOT NULL,
    wilaya_code smallint,
    phone_sms text,
    capabilities text[] DEFAULT '{}'::text[] NOT NULL,
    location extensions.geography(Point,4326) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    CONSTRAINT hospitals_capabilities_check CHECK ((capabilities <@ ARRAY['ed24'::text, 'trauma_surgery'::text, 'ct'::text, 'icu'::text, 'neurosurgery'::text, 'pediatrics'::text, 'burns'::text, 'general_surgery'::text])),
    CONSTRAINT hospitals_level_check CHECK ((level = ANY (ARRAY['A'::text, 'B'::text, 'C'::text])))
);


--
-- Name: incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incidents (
    id text NOT NULL,
    status public.incident_status DEFAULT 'RECEIVED'::public.incident_status NOT NULL,
    band public.band NOT NULL,
    nsi smallint NOT NULL,
    conf text NOT NULL,
    location extensions.geography(Point,4326) NOT NULL,
    plus_code text,
    crashed_at timestamp with time zone NOT NULL,
    first_channel text NOT NULL,
    merged_count smallint DEFAULT 1 NOT NULL,
    assigned_unit text,
    hospital_id text,
    wilaya_code smallint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    band_override public.band,
    CONSTRAINT incidents_conf_check CHECK ((conf = ANY (ARRAY['H'::text, 'M'::text, 'L'::text]))),
    CONSTRAINT incidents_first_channel_check CHECK ((first_channel = ANY (ARRAY['https'::text, 'sms'::text, 'paste'::text, 'witness'::text, 'sim'::text]))),
    CONSTRAINT incidents_id_check CHECK ((id ~ '^[0-9A-HJKMNP-TV-Z]{5}$'::text)),
    CONSTRAINT incidents_nsi_check CHECK (((nsi >= 0) AND (nsi <= 99)))
);


--
-- Name: prealerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prealerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_id text NOT NULL,
    hospital_id text NOT NULL,
    channel text NOT NULL,
    body text,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    acked_at timestamp with time zone,
    acked_by text,
    CONSTRAINT prealerts_channel_check CHECK ((channel = ANY (ARRAY['web'::text, 'sms'::text])))
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    user_id uuid NOT NULL,
    role text NOT NULL,
    hospital_id text,
    display_name text,
    CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['dispatcher'::text, 'hospital'::text, 'admin'::text])))
);


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_id text,
    client_id text,
    channel text NOT NULL,
    source text NOT NULL,
    raw text NOT NULL,
    parsed jsonb,
    parse_error text,
    sender_hash text,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT reports_channel_check CHECK ((channel = ANY (ARRAY['https'::text, 'sms'::text, 'paste'::text, 'witness'::text, 'sim'::text, 'crew'::text]))),
    CONSTRAINT reports_check CHECK (((parsed IS NULL) = (parse_error IS NOT NULL))),
    CONSTRAINT reports_check1 CHECK (((parse_error IS NOT NULL) OR (client_id IS NOT NULL))),
    CONSTRAINT reports_client_id_check CHECK ((client_id ~ '^[0-9A-HJKMNP-TV-Z]{5}$'::text)),
    CONSTRAINT reports_source_check CHECK ((source = ANY (ARRAY['auto'::text, 'witness'::text, 'sos'::text, 'crew'::text, 'unknown'::text])))
);


--
-- Name: sms_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_outbox (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    to_number text,
    body text NOT NULL,
    purpose text NOT NULL,
    incident_id text,
    status text DEFAULT 'queued'::text NOT NULL,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    CONSTRAINT sms_outbox_purpose_check CHECK ((purpose = ANY (ARRAY['ack'::text, 'prealert'::text, 'status_reply'::text, 'crew_update'::text]))),
    CONSTRAINT sms_outbox_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'sent'::text, 'failed'::text, 'simulated'::text, 'no_number'::text])))
);


--
-- Data for Name: assessments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assessments (id, incident_id, version, band, nsi, conf, reasons, inputs, engine_version, created_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_events (id, incident_id, actor, action, before, after, reason, at) FROM stdin;
1	\N	dispatcher:Dispatcher (demo)	demo.reset	\N	\N	demo reset	2026-10-31 04:54:07.716053+00
\.


--
-- Data for Name: eta_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eta_cache (origin_key, hospital_id, minutes, km, source, computed_at) FROM stdin;
\.


--
-- Data for Name: hospital_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hospital_status (hospital_id, status, set_by, set_at) FROM stdin;
EPH-B	OK	seed	2026-10-31 04:54:07.716053+00
CHU-C	SATURATED	seed	2026-10-31 04:54:07.716053+00
\.


--
-- Data for Name: hospitals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hospitals (id, name, level, wilaya_code, phone_sms, capabilities, location, source, verified) FROM stdin;
EPH-D	EPH D (illustrative)	B	9	\N	{ed24,general_surgery,pediatrics}	0101000020E6100000EC51B81E85EB054014AE47E17A344240	illustrative	f
N-EPH-HOPITAL-D-AOULEF	Hôpital d'Aoulef (unverified)	B	1	\N	{ed24,general_surgery}	0101000020E61000009964E42CEC69F13FE140481630F93A40	osm-unverified	f
N-EPH-HOPITAL-IBN-SINA-1	Hôpital Ibn Sina (unverified)	B	1	\N	{ed24,general_surgery}	0101000020E61000003A4030478FDFD1BF10CCD1E3F7DE3B40	osm-unverified	f
N-EPH-HOPITAL-BLEU	Hôpital bleu (unverified)	B	17	\N	{ed24,general_surgery}	0101000020E6100000C442AD69DEF10B4080608E1EBF134140	osm-unverified	f
N-EPH-HOPITAL-MUNICIPAL	Hôpital municipal (unverified)	B	1	\N	{ed24,general_surgery}	0101000020E6100000014D840D4FAFC8BF1878EE3D5C3A3B40	osm-unverified	f
N-EPH-FACILITY-112	مستشفى عين مران (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E6100000D23AAA9A20EAEE3FBF9A030473144240	osm-unverified	f
N-EPH-EPH-BELHI-ABDELHAM	EPH Belhi Abdelhamid (unverified)	B	43	\N	{ed24,general_surgery}	0101000020E6100000087767EDB6EB17404F3BFC35590F4240	osm-unverified	f
N-EPH-HOPITAL-CHELGHOUM-	Hôpital Chelghoum Laïd (unverified)	B	43	\N	{ed24,general_surgery}	0101000020E610000069C6A2E9ECA4184076374F75C8154240	osm-unverified	f
N-EPH-HOPITAL-DE-MILA	Hôpital de Mila (unverified)	B	43	\N	{ed24,general_surgery}	0101000020E6100000CD1E6805860C19400D54C6BFCF384240	osm-unverified	f
N-EPH-HOPITAL-DES-FRERES	Hôpital des frères Boukhechem (unverified)	B	43	\N	{ed24,general_surgery}	0101000020E61000001327F73B14251940BFD4CF9B8A204240	osm-unverified	f
N-EPH-HOPITAL-MOHAMED-ME	Hopital Mohamed Meddahi (unverified)	B	43	\N	{ed24,general_surgery}	0101000020E6100000E9F17B9BFECC1740DC2E34D769344240	osm-unverified	f
N-EPH-HOSPITAL	hospital (unverified)	B	43	\N	{ed24,general_surgery}	0101000020E6100000E44EE960FDDF174073637AC2120F4240	osm-unverified	f
N-EPH-EPH-MAKOUR-HAMOU	EPH Makour Hamou (unverified)	B	44	\N	{ed24,general_surgery}	0101000020E6100000971C774A076BFF3F1973D712F2214240	osm-unverified	f
N-EPH-FACILITY-576	مستشفى المجاهد المرحوم ماجن بن ميرة (unverified)	B	44	\N	{ed24,general_surgery}	0101000020E61000002384471B47ACFF3FB4C876BE9F224240	osm-unverified	f
N-EPH-HOPITAL-FARES-YAHI	Hôpital Fares Yahia (unverified)	B	44	\N	{ed24,general_surgery}	0101000020E61000007A53910A63CB0140CA54C1A8A4264240	osm-unverified	f
N-EPH-HOPITAL-MIXTE-TATI	Hôpital Mixte Tati-Argali (unverified)	B	50	\N	{ed24,general_surgery}	0101000020E610000062BEBC00FBE8EE3F32384A5E9D533540	osm-unverified	f
N-EPH-HOPITAL-MOHAMED-YA	Hôpital Mohamed Yagoub (unverified)	B	51	\N	{ed24,general_surgery}	0101000020E6100000450DA661F84801C09B3DD00A0C213E40	osm-unverified	f
N-EPH-FACILITY-185	المستشفى القديم (unverified)	B	52	\N	{ed24,general_surgery}	0101000020E61000009291B3B0A7FD13409F76F86BB2324140	osm-unverified	f
N-EPH-HOPITAL-ACHOUR-ZIA	Hôpital Achour Ziane (unverified)	B	52	\N	{ed24,general_surgery}	0101000020E61000005A8121AB5B3D14406DAD2F12DA364140	osm-unverified	f
N-EPH-HOPITAL-CHORFA	Hôpital Chorfa (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E610000031B610E4A004F53F745E6397A8124240	osm-unverified	f
N-EPH-HOPITAL-D-OUED-FOD	Hôpital d'Oued Fodda (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E610000025E99AC9375BF83FD66EBBD05C174240	osm-unverified	f
N-EPH-HOPITAL-DE-SOBHA	Hôpital de SOBHA (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E610000075594C6C3EAEF13F8CF84ECC7A0D4240	osm-unverified	f
N-EPH-HOPITAL-DE-TENES	Hôpital de Ténès (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E61000008195438B6CE7F43F76E09C11A5414240	osm-unverified	f
N-EPH-HOPITAL-DES-S-URS-	Hôpital des sœurs Bedj (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E61000005053CBD6FA22F53FB1169F0260144240	osm-unverified	f
N-EPH-HOPITAL-EL-MARSA	Hopital El marsa مستشفى المرسى (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E61000005CE674594C6CED3FF9DA334B02344240	osm-unverified	f
N-EPH-HOPITAL-MEROUANI-A	Hopital Merouani Abed (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E610000076711B0DE02DF43F274EEE77281A4240	osm-unverified	f
N-EPH-HOPITAL-OULED-MOHA	Hôpital Ouled Mohamed (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E6100000257A19C572CBF53F15C616821C144240	osm-unverified	f
N-EPH-ZIGHOUD-YOUSSEF-HO	Zighoud Youssef Hospital (unverified)	B	2	\N	{ed24,general_surgery}	0101000020E6100000DC9DB5DB2EB4F43F9CA73AE466404240	osm-unverified	f
N-EPH-FACILITY-124	مستشفى تاجموت (unverified)	B	3	\N	{ed24,general_surgery}	0101000020E6100000117008556A360440789CA223B9F04040	osm-unverified	f
N-EPH-HOPITAL-240-LITS-L	Hôpital 240 lits Laghouat (unverified)	B	3	\N	{ed24,general_surgery}	0101000020E610000006BB61DBA2CC0640BEA4315A47E54040	osm-unverified	f
N-EPH-HOPITAL-AHMAIDA-BE	Hôpital Ahmaida Ben Adjila (unverified)	B	3	\N	{ed24,general_surgery}	0101000020E61000002159C0046EDD0640D7FA22A12DE74040	osm-unverified	f
N-EPH-HOPITAL-HASSI-D-EL	Hôpital hassi d'Ella مستشفى حاسي دلاعة (unverified)	B	3	\N	{ed24,general_surgery}	0101000020E6100000EACA67791E5C0C4014E8137992B44040	osm-unverified	f
CHU-A	CHU A (illustrative)	A	9	+213555000101	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E6100000643BDF4F8D970740B29DEFA7C64B4240	illustrative	f
EPH-B	EPH B (illustrative)	B	9	+213555000102	{ed24,general_surgery,trauma_surgery,ct}	0101000020E61000006F1283C0CAA10640A4703D0AD7434240	illustrative	f
CHU-C	CHU C (illustrative)	A	9	+213555000103	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,burns}	0101000020E610000046B6F3FDD4780440BC74931804164240	illustrative	f
PU-E	Polyclinic E (illustrative)	C	9	\N	{ed24}	0101000020E610000033333333333307409A99999999394240	illustrative	f
CHU-F	CHU F (illustrative)	A	16	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics,burns}	0101000020E61000007B14AE47E17A08408FC2F5285C5F4240	illustrative	f
EPH-G	EPH G (illustrative)	B	16	\N	{ed24,general_surgery,ct,icu}	0101000020E6100000D7A3703D0AD707405C8FC2F5285C4240	illustrative	f
EPH-H	EPH H (illustrative)	B	16	\N	{ed24,general_surgery,pediatrics}	0101000020E61000005C8FC2F5285C0940B81E85EB51584240	illustrative	f
CHU-O	CHU O (illustrative)	A	31	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E6100000AE47E17A14AEE3BF0AD7A3703DDA4140	illustrative	f
EPH-P	EPH P (illustrative)	B	31	\N	{ed24,general_surgery,ct,pediatrics}	0101000020E6100000CDCCCCCCCCCCE4BFD7A3703D0AD74140	illustrative	f
EPH-Q	EPH Q (illustrative)	B	31	\N	{ed24,general_surgery,trauma_surgery}	0101000020E6100000EC51B81E85EBE1BF1F85EB51B8DE4140	illustrative	f
PU-R	Polyclinic R (illustrative)	C	31	\N	{ed24}	0101000020E6100000666666666666E6BF14AE47E17AD44140	illustrative	f
N-CHU-BEJAIA-KHELLIL	CHU Khellil Amrane (Bejaia) (unverified)	A	6	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E61000001283C0CAA1451440713D0AD7A3604240	osm-unverified	f
N-EPH-HOPITAL-ZIOUCHI-MO	Hôpital Ziouchi Mohamed (unverified)	B	7	\N	{ed24,general_surgery}	0101000020E6100000F3936A9F8E871540D40E7F4DD65C4140	osm-unverified	f
N-CHU-BECHAR-BOUDJEMAA	CHU Tourabi Boudjemaa (Bechar) (unverified)	A	8	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E6100000986E1283C0CA01C0E5D022DBF99E3F40	osm-unverified	f
N-EPH-HOPITAL-BENI-OUNIF	Hôpital Beni Ounif (unverified)	B	8	\N	{ed24,general_surgery}	0101000020E6100000925CFE43FAEDF3BFE162450DA6054040	osm-unverified	f
N-EPH-HOPITAL-BOUDIAF	Hôpital Boudiaf (unverified)	B	8	\N	{ed24,general_surgery}	0101000020E6100000DF1AD82AC1A201C05726FC523F9F3F40	osm-unverified	f
N-EPH-HOPITAL-DE-ABADLA	Hopital de ABADLA (unverified)	B	8	\N	{ed24,general_surgery}	0101000020E6100000B77A4E7ADFF805C071AC8BDB68003F40	osm-unverified	f
N-EPH-HOPITAL-TOURABI-BO	Hôpital Tourabi Boudjemaa (unverified)	B	8	\N	{ed24,general_surgery}	0101000020E61000009E98F56228E701C0609335EA219A3F40	osm-unverified	f
N-CHU-BLIDA-FRANTZ-FANON	CHU Frantz Fanon (Blida) (unverified)	A	9	+213555000201	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics,burns}	0101000020E6100000B2683A3B195C0640350708E6E83D4240	osm-unverified	f
N-EPH-BLIDA-IBN-ROCHD	EPH Ibn Rochd (Blida) (unverified)	B	9	+213555000202	{ed24,general_surgery}	0101000020E6100000D9CEF753E3A506403108AC1C5A3C4240	osm-unverified	f
N-EPH-BOUFARIK	EPH de Boufarik (unverified)	B	9	\N	{ed24,general_surgery}	0101000020E61000009F8EC70C5446074092054CE0D6494240	osm-unverified	f
N-EPH-EL-AFFROUN	EPH El Affroun (unverified)	B	9	\N	{ed24,general_surgery}	0101000020E6100000D8F0F44A5906054007F01648503C4240	osm-unverified	f
N-EPH-HOPITAL-BRAHIM-TIR	Hôpital Brahim Tirichine (unverified)	B	9	\N	{ed24,general_surgery}	0101000020E61000005FD218ADA3AA0640704221020E3D4240	osm-unverified	f
N-EPH-HOPITAL-DE-MEFTAH	Hôpital de Meftah (unverified)	B	9	\N	{ed24,general_surgery}	0101000020E610000054A9D903ADC0094031B1F9B8364C4240	osm-unverified	f
N-EPH-HOPITAL-HASSIBA-BE	Hôpital Hassiba Ben Bouali (unverified)	B	9	\N	{ed24,general_surgery}	0101000020E61000006362F3716DA80640751F80D4263E4240	osm-unverified	f
N-EPH-HOPITAL-M-HAMED-YA	Hôpital M'Hamed Yazid (unverified)	B	9	\N	{ed24,general_surgery}	0101000020E6100000D1915CFE437A064053AEF02E173D4240	osm-unverified	f
N-EPH-MEFTAH	EPH Meftah (unverified)	B	9	\N	{ed24,general_surgery}	0101000020E6100000B29DEFA7C6CB094001DE02098A4F4240	osm-unverified	f
N-EPH-EPH-LAKHDARIA	EPH LAKHDARIA (unverified)	B	10	\N	{ed24,general_surgery}	0101000020E61000008E06F01648D00C404417D4B7CC494240	osm-unverified	f
N-EPH-HOPITAL-BECHELOUL	Hôpital becheloul (unverified)	B	10	\N	{ed24,general_surgery}	0101000020E6100000D942908312461040959A3DD00A284240	osm-unverified	f
N-EPH-HOPITAL-DE-AIN-BES	Hôpital de Aïn Bessam (unverified)	B	10	\N	{ed24,general_surgery}	0101000020E6100000B83B6BB75D680D409981CAF8F7254240	osm-unverified	f
N-EPH-HOPITAL-MOHAMED-BO	Hôpital Mohamed Boudiaf (unverified)	B	10	\N	{ed24,general_surgery}	0101000020E6100000A779C7293A120F407A36AB3E572F4240	osm-unverified	f
N-EPH-MAHMOUD-GOUMAMA-S-	Mahmoud Goumama's Hospital (unverified)	B	11	\N	{ed24,general_surgery}	0101000020E610000098512CB7B43A16404BAB21718FCD3640	osm-unverified	f
N-EPH-EPH-MORSOTT	EPH MORSOTT (unverified)	B	12	\N	{ed24,general_surgery}	0101000020E6100000F46C567DAE062040A774B0FECFD54140	osm-unverified	f
N-EPH-HOPITAL-KHALDI-ABD	Hôpital Khaldi Abdelaziz (unverified)	B	12	\N	{ed24,general_surgery}	0101000020E6100000CEDF8442043C2040E40F069E7BB34140	osm-unverified	f
N-EPH-HOPITAL-TIDJANI-HA	Hôpital Tidjani Hadam (unverified)	B	12	\N	{ed24,general_surgery}	0101000020E6100000273108AC1C1A2040A20BEA5BE6604140	osm-unverified	f
N-EPH-HOUAM-ALI-HOSPITAL	Houam Ali hospital (unverified)	B	12	\N	{ed24,general_surgery}	0101000020E61000002FDD2406810520402046088F36D64140	osm-unverified	f
N-CHU-TLEMCEN-DAMERDJI	CHU Tidjani Damerdji (Tlemcen) (unverified)	A	13	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E6100000DF4F8D976E12F5BFA8C64B3789714140	osm-unverified	f
N-EPH-EPH-CHAABANE-HAMDO	EPH Chaabane Hamdoun (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E61000008D976E1283C0FBBF9E29745E636B4140	osm-unverified	f
N-EPH-EPH-NEDROMA	EPH Nedroma (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E6100000D8B628B34126FCBFE71DA7E848824140	osm-unverified	f
N-EPH-FACILITY-463	مستشفى المنصورة (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E61000002F8672A25DE511408CF337A110094240	osm-unverified	f
N-EPH-HOPITAL-DE-BAB-EL-	Hôpital de Bab El Assa (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E610000002486DE2E43E00C0492EFF21FD7A4140	osm-unverified	f
N-EPH-HOPITAL-DR-BENZARD	Hopital Dr. Benzardjeb Benaouda (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E61000000135B56CAD2FF5BF75CDE49B6D524140	osm-unverified	f
N-EPH-HOPITAL-DR-TIDJANI	Hôpital Dr Tidjani Damerdji (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E6100000CE8DE9094B3CF5BF325A475513704140	osm-unverified	f
N-EPH-HOPITAL-EPH-REMCHI	Hôpital EPH Remchi (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E610000037894160E5D0F6BF200C3CF71E864140	osm-unverified	f
N-EPH-HOPITAL-MAALEM-LAH	Hôpital Maalem Lahcen (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E6100000CB2DAD86C4BDFDBFA5315A47558B4140	osm-unverified	f
N-EPH-HOPITAL-PRIVE	Hôpital privé (unverified)	B	13	\N	{ed24,general_surgery}	0101000020E6100000696FF085C9D4F6BF47E6913F18884140	osm-unverified	f
N-EPH-FACILITY-290	مستشفى محمد بوضياف (unverified)	B	14	\N	{ed24,general_surgery}	0101000020E6100000787FBC57AD4CFC3F88D7F50B76B74140	osm-unverified	f
N-EPH-HOPITAL-GHERMIT-NA	hôpital ghermit naseur (unverified)	B	14	\N	{ed24,general_surgery}	0101000020E61000003ED00A0C59DDF73F0E10CCD1E3974140	osm-unverified	f
N-EPH-HOPITAL-HICHEM-ABD	Hôpital Hichem Abdelkrim (unverified)	B	14	\N	{ed24,general_surgery}	0101000020E61000007380608E1EBFF83F31D3F6AFAC6C4140	osm-unverified	f
N-EPH-HOPITAL-IBN-SINA	Hôpital Ibn Sina (unverified)	B	14	\N	{ed24,general_surgery}	0101000020E6100000CE531D7233DCF03F9CA223B9FC874140	osm-unverified	f
N-EPH-HOPITAL-TORKI-NORE	Hopital Torki Noredine (unverified)	B	14	\N	{ed24,general_surgery}	0101000020E6100000CC4065FCFB8CF73F3EB324404DB54140	osm-unverified	f
N-CHU-TIZI-OUZOU-NEDIR	CHU Nedir Mohamed (Tizi Ouzou) (unverified)	A	15	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E610000047ACC5A700381040C24CDBBFB25A4240	osm-unverified	f
N-EPH-AZAZGA	EPH Meghnem Lounes (Azazga) (unverified)	B	15	\N	{ed24,general_surgery}	0101000020E6100000B0726891ED7C1140AC1C5A643B5F4240	osm-unverified	f
N-EPH-DRAA-EL-MIZAN	EPH Krim Belkacem (Draa El Mizan) (unverified)	B	15	\N	{ed24,general_surgery}	0101000020E610000079E9263108AC0E40F853E3A59B444240	osm-unverified	f
N-EPH-HOPITAL-AHMED-ALI-	HOPITAL AHMED ALI AMMAR (unverified)	B	15	\N	{ed24,general_surgery}	0101000020E6100000F1D7648D7A281140DBC4C9FD0E494240	osm-unverified	f
N-EPH-HOPITAL-CHAHIDS-MA	Hôpital Chahids Mahmoudi (unverified)	B	15	\N	{ed24,general_surgery}	0101000020E61000002AA913D044381040FD4D2844C0594240	osm-unverified	f
N-EPH-HOPITAL-DE-LARBAA-	Hôpital de Larbâa N'Aït Irathen (unverified)	B	15	\N	{ed24,general_surgery}	0101000020E610000040C1C58A1ACC10400A85083884524240	osm-unverified	f
N-EPH-HOPITAL-KRIM-BELKA	Hôpital Krim Belkacem (unverified)	B	15	\N	{ed24,general_surgery}	0101000020E610000030F0DC7BB8A40E400E84640113444240	osm-unverified	f
N-EPH-HOPITAL-POUR-ENFAN	Hôpital pour enfants cardiaques (unverified)	B	15	\N	{ed24,general_surgery}	0101000020E6100000FFCF61BEBCC00F40613255302A5D4240	osm-unverified	f
N-EPH-HOPITAL-SIDI-BELLO	Hôpital Sidi Belloua Sanatorium (unverified)	B	15	\N	{ed24,general_surgery}	0101000020E610000050DF32A7CB4210400CE544BB0A5D4240	osm-unverified	f
N-CHU-BAB-EL-OUED	CHU Mohamed Lamine Debaghine (Bab El Oued) (unverified)	A	16	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E610000032207BBDFB630840BDC62E51BD654240	osm-unverified	f
N-CHU-BENI-MESSOUS	CHU Issad Hassani (Beni Messous) (unverified)	A	16	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E610000062DBA2CC06D907402B4D4A41B7634240	osm-unverified	f
N-CHU-DOUERA	CHU Djillali Bounaama (Douera) (unverified)	A	16	\N	{ed24,general_surgery,trauma_surgery,ct,icu,burns,pediatrics}	0101000020E6100000C520B07268910740D9CEF753E3554240	osm-unverified	f
N-CHU-MUSTAPHA	CHU Mustapha Pacha (unverified)	A	16	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics,burns}	0101000020E610000020240B98C06D0840E10B93A982614240	osm-unverified	f
N-CHU-PARNET	CHU Nafissa Hamoud (Parnet - Hussein Dey) (unverified)	A	16	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E6100000F2D24D6210D8084058A835CD3B5E4240	osm-unverified	f
N-EHS-AIT-IDIR	EHS Ali Ait Idir (Neurochirurgie) (unverified)	A	16	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery}	0101000020E61000006475ABE7A4770840696FF085C9644240	osm-unverified	f
N-EHS-ZERALDA-BURNS	EHS Said Chibane - Grands Brules (Zeralda) (unverified)	A	16	\N	{ed24,general_surgery,trauma_surgery,ct,icu,burns,pediatrics}	0101000020E610000039D6C56D34C00640BD8C62B9A5594240	osm-unverified	f
N-EPH-AIN-TAYA	EPH Ain Taya (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000B0AC3429055D0A40CC7A319413654240	osm-unverified	f
N-EPH-BOLOGHINE	EPH Bologhine Ibn Ziri (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000F792C6681DD50740AB5B3D27BD674240	osm-unverified	f
N-EPH-EL-BIAR	EPH Birtraria (El Biar) (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000ABCFD556EC2F084060E5D022DB614240	osm-unverified	f
N-EPH-EPH-DJILLALI-BELKH	EPH Djillali Belkhenchir - El Biar (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000179AEB34D252084090F7AA9509634240	osm-unverified	f
N-EPH-HOPITAL-AZUR-PLAGE	Hôpital Azur Plage (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000DEC83CF207C306406E3480B7405E4240	osm-unverified	f
N-EPH-HOPITAL-BOUCHAWI	Hôpital Bouchawi (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000F0164850FC180740C4CE143AAF5D4240	osm-unverified	f
N-EPH-HOPITAL-DE-BOUKHRO	Hôpital de Boukhroufa Abdelkader - Ben Aknoun (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000FD135CACA80108408DD13AAA9A604240	osm-unverified	f
N-EPH-HOPITAL-DE-TIXERAI	Hôpital de Tixeraïne (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E61000005B423EE8D92C08407FC16ED8B65C4240	osm-unverified	f
N-EPH-HOPITAL-DES-BRULES	Hôpital des brûlés (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000A33B889D2974084050FC1873D7624240	osm-unverified	f
N-EPH-HOPITAL-EL-HADI-FL	Hôpital El Hadi Flici (El Kettar) (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E61000000BB5A679C76908404D10751F80644240	osm-unverified	f
N-EPH-HOPITAL-ZIROUD-YOU	Hôpital Ziroud Yousef (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000A167B3EA733508407FA4880CAB644240	osm-unverified	f
N-EPH-HOSPITAL-DE-ZGHARA	Hospital de zghara (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E61000009A5FCD01823908406CB2463D44674240	osm-unverified	f
N-EPH-KOUBA	EPH Dr Bechir Bennacer (Kouba) (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E61000001B0DE02D90A008406ADE718A8E5C4240	osm-unverified	f
N-EPH-MOTHER-AND-CHILD-M	Mother and Child Military Hospital (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E61000000C93A98251C907403480B74082624240	osm-unverified	f
N-EPH-SERVICE-MEDECINE-I	Service Médecine Interne d'Hôpital Birtraria (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000DB6D179AEB3408403C4ED1915C624240	osm-unverified	f
N-EPH-ZEMIRLI	EPH Salim Zemirli (El Harrach - Traumatologie) (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000E8BCC62E51FD084027F73B14055A4240	osm-unverified	f
N-HCA-AIN-NAADJA	Hopital Central de l Armee (Ain Naadja) (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E6100000508D976E12830840B4C876BE9F5A4240	osm-unverified	f
N-EPH-EHS-MOTHER-AND-CHI	EHS Mother and Child Hospital (unverified)	B	17	\N	{ed24,general_surgery}	0101000020E6100000CBB9145795FD0940764F1E166A554140	osm-unverified	f
N-EPH-FACILITY-177	مستشفى الدويس (unverified)	B	17	\N	{ed24,general_surgery}	0101000020E6100000C9AB730CC89E0540DE76A1B94E2F4140	osm-unverified	f
N-EPH-HOPITAL-DE-BIRINE	Hôpital de Birine (unverified)	B	17	\N	{ed24,general_surgery}	0101000020E610000089981249F4B209400F0BB5A679CF4140	osm-unverified	f
N-EPH-HOPITAL-EL-IDRISSI	Hôpital El Idrissia (unverified)	B	17	\N	{ed24,general_surgery}	0101000020E6100000C7293A92CB3F04409FC893A46B3A4140	osm-unverified	f
N-EPH-LE-GRAND-HOPITAL	Le grand Hopital (unverified)	B	17	\N	{ed24,general_surgery}	0101000020E6100000E0D6DD3CD5E10B4047C9AB730C144140	osm-unverified	f
N-EPH-HOPITAL-BACHIR-MEN	Hôpital Bachir Mentouri (unverified)	B	18	\N	{ed24,general_surgery}	0101000020E6100000DD0C37E0F3231940BE4D7FF623614240	osm-unverified	f
N-EPH-HOPITAL-MADJDOUB-S	Hôpital Madjdoub Saïd (unverified)	B	18	\N	{ed24,general_surgery}	0101000020E610000070B6B9313DA11740D482177D05654240	osm-unverified	f
N-CHU-SETIF-SAADNA	CHU Saadna Mohamed Abdenour (Setif) (unverified)	A	19	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E61000002575029A089B1540462575029A184240	osm-unverified	f
N-EPH-AIN-OULMENE	EPH Mohamed Boudiaf (Ain Oulmene) (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E610000010E9B7AF03271540B0726891EDF44140	osm-unverified	f
N-EPH-EL-EULMA	EPH Saroub El-Hadj (El Eulma) (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E6100000986E1283C0CA1640A4703D0AD7134240	osm-unverified	f
N-EPH-HOPITAL-AMOUCHA	hôpital amoucha (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E6100000BE4D7FF623A5154095D4096822304240	osm-unverified	f
N-EPH-HOPITAL-ARASSA	Hôpital Arassa (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E6100000401361C3D34B134003098A1F63364240	osm-unverified	f
N-EPH-ROUIBA	EPH de Rouiba (unverified)	B	16	\N	{ed24,general_surgery}	0101000020E61000007C2766BD184A0A4019CA8976155E4240	osm-unverified	f
N-EPH-HOPITAL-BLILITA	Hôpital Blilita (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E6100000FEF15EB532211540456458C51BED4140	osm-unverified	f
N-EPH-HOPITAL-CHEGHOUB-A	Hopital Cheghoub Abdellah (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E61000003F8C101E6DFC1540FBE8D495CF2E4240	osm-unverified	f
N-EPH-HOPITAL-SAID-AOUAM	Hopital Said Aouamri (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E61000009031772D215F14401EE1B4E0452B4240	osm-unverified	f
N-EPH-HOPITAL-SAROUB-EL-	Hôpital Saroub El Khatir (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E610000024456458C5BB16401E6D1CB116134240	osm-unverified	f
N-EPH-HOPITAL-YOUCEF-YAA	Hôpital Youcef Yaalaoui (unverified)	B	19	\N	{ed24,general_surgery}	0101000020E6100000F67F0EF3E5051640014D840D4FE74140	osm-unverified	f
N-EPH-EPH-AHMED-MEDEGHRI	EPH Ahmed MEDEGHRI (unverified)	B	20	\N	{ed24,general_surgery}	0101000020E61000003A0664AF777FC43F274EEE77286A4140	osm-unverified	f
N-EPH-HOPITAL-D-EL-HARRO	Hôpital d'El Harrouch (unverified)	B	21	\N	{ed24,general_surgery}	0101000020E610000098A3C7EF6D5A1B40247F30F0DC534240	osm-unverified	f
N-EPH-HOPITAL-DE-COLLO	Hôpital de Collo (unverified)	B	21	\N	{ed24,general_surgery}	0101000020E610000008944DB9C23B1A40FE0E45813E814240	osm-unverified	f
N-EPH-HOPITAL-DE-SKIKDA	Hôpital de Skikda (unverified)	B	21	\N	{ed24,general_surgery}	0101000020E61000006E6E4C4F58A21B40F71E2E39EE704240	osm-unverified	f
N-EPH-NOUVEL-HOPITAL-ABD	Nouvel Hôpital Abderezzak Bouhara (unverified)	B	21	\N	{ed24,general_surgery}	0101000020E6100000BA2C26361F971B4026DF6C73636E4240	osm-unverified	f
N-CHU-SBA-HASSANI	CHU Docteur Hassani Abdelkader (Sidi Bel Abbes) (unverified)	A	22	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E61000006C09F9A067B3E4BF8FC2F5285C974140	osm-unverified	f
N-EPH-EPH-SIDI-BEL-ABBES	EPH Sidi Bel Abbès (unverified)	B	22	\N	{ed24,general_surgery}	0101000020E61000002D431CEBE236E4BFDD0C37E0F39B4140	osm-unverified	f
N-EPH-HOPITAL-DE-AIN-EL-	Hôpital de Aïn El Berd (unverified)	B	22	\N	{ed24,general_surgery}	0101000020E610000023A12DE7525CE0BFE63FA4DFBEAE4140	osm-unverified	f
N-EPH-HOPITAL-DE-TELAGH	Hôpital de Telagh (unverified)	B	22	\N	{ed24,general_surgery}	0101000020E61000008FAA2688BA0FE2BF2B6A300DC3634140	osm-unverified	f
N-CHU-ANNABA-DORBAN	CHU Dorban (Annaba) (unverified)	A	23	\N	{ed24,general_surgery,ct,icu,pediatrics}	0101000020E6100000B329577897EB1E40312592E865744240	osm-unverified	f
N-EPH-HOPITAL-D-EL-AOUIN	Hôpital d'El Aouinet (unverified)	B	41	\N	{ed24,general_surgery}	0101000020E6100000C85EEFFE788F1F40BCE82B4833EE4140	osm-unverified	f
N-CHU-ANNABA-IBN-ROCHD	CHU Ibn Rochd (Annaba) (unverified)	A	23	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E6100000CD0182397AFC1E407F6ABC7493744240	osm-unverified	f
N-EPH-HOPITAL-AHMED-GOUA	Hôpital Ahmed Gouasmi (unverified)	B	23	\N	{ed24,general_surgery}	0101000020E61000006C3EAE0D15831D40639CBF0985884240	osm-unverified	f
N-EPH-HOPITAL-D-EL-HADJA	Hopital d'El-hadjar (unverified)	B	23	\N	{ed24,general_surgery}	0101000020E61000000ABABDA431FA1E405778978BF8664240	osm-unverified	f
N-EPH-HOPITAL-DE-AIN-BER	Hopital de Ain Berda (unverified)	B	23	\N	{ed24,general_surgery}	0101000020E6100000CE531D72335C1E40ECDD1FEF55534240	osm-unverified	f
N-EPH-HOPITAL-IBN-SINA-E	Hôpital Ibn Sina (ex Caroubier) (unverified)	B	23	\N	{ed24,general_surgery}	0101000020E6100000E223624A24111F4016DEE522BE734240	osm-unverified	f
N-EPH-HOPITAL-DE-BOUCHEG	Hôpital de Bouchegouf (unverified)	B	24	\N	{ed24,general_surgery}	0101000020E6100000499D8026C2E61E401CB62DCA6C3C4240	osm-unverified	f
N-EPH-HOPITAL-EL-HAKIM-O	Hôpital El Hakim Okbi (unverified)	B	24	\N	{ed24,general_surgery}	0101000020E61000009279E40F06BE1D404A9869FB573A4240	osm-unverified	f
N-EPH-NOUVEL-HOPITAL-DE--1	Nouvel Hôpital de Guelma (unverified)	B	24	\N	{ed24,general_surgery}	0101000020E6100000F65D11FC6FC51D40EF2076A6D0394240	osm-unverified	f
N-CHU-CONSTANTINE-BENBADIS	CHU Ibn Badis (Constantine) (unverified)	A	25	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics,burns}	0101000020E6100000643BDF4F8D771A4032ACE28DCC2F4240	osm-unverified	f
N-EPH-EL-KHROUB	EPH Mohamed Boudiaf (El Khroub) (unverified)	B	25	\N	{ed24,general_surgery}	0101000020E61000007D3F355EBAC91A40A8C64B3789214240	osm-unverified	f
N-EPH-EPH-DIDOUCHE-MORAD	EPH Didouche Morad (unverified)	B	25	\N	{ed24,general_surgery}	0101000020E6100000130F289B72851A40F5F3A622153A4240	osm-unverified	f
N-EPH-EPH-EL-KHROUB	EPH EL KHROUB (unverified)	B	25	\N	{ed24,general_surgery}	0101000020E6100000DA5548F949D51A40056EDDCD53214240	osm-unverified	f
N-EPH-HOPITAL-HAFID-BOUD	Hôpital hafid boudjema (unverified)	B	25	\N	{ed24,general_surgery}	0101000020E6100000FFCF61BEBC601A40E2CCAFE6002D4240	osm-unverified	f
N-EPH-FACILITY-333	مستشفى محمّد بوضياف (unverified)	B	26	\N	{ed24,general_surgery}	0101000020E610000072BF4351A00F06404CE0D6DD3C214240	osm-unverified	f
N-EPH-HOPITAL-DE-CHELLAL	Hôpital de Chellalet El Adhaoura (unverified)	B	26	\N	{ed24,general_surgery}	0101000020E610000052448655BC510B40B8921D1B81F84140	osm-unverified	f
N-EPH-HOPITAL-EPH-KSAR-E	Hôpital EPH Ksar el Boukhari (unverified)	B	26	\N	{ed24,general_surgery}	0101000020E6100000EE7C3F355EFA054045F5D6C056F14140	osm-unverified	f
N-EPH-HOPITAL-EPH-SAID-O	Hopital EPH Said Omar (unverified)	B	26	\N	{ed24,general_surgery}	0101000020E6100000A3409FC893640A40DBA2CC06991C4240	osm-unverified	f
N-EPH-13-HOSPITAL	13 - hospital (unverified)	B	27	\N	{ed24,general_surgery}	0101000020E6100000B1E1E995B20CB93F598B4F0130FA4140	osm-unverified	f
N-EPH-EPH-BOUGUIRAT	EPH Bouguirat (unverified)	B	27	\N	{ed24,general_surgery}	0101000020E6100000DF4F8D976E12D13F401361C3D3DF4140	osm-unverified	f
N-EPH-FACILITY-300	مستشفى المجاهد غالم (unverified)	B	27	\N	{ed24,general_surgery}	0101000020E610000052F2EA1C03B2E53F766C04E275294240	osm-unverified	f
N-EPH-HOPITAL-ADJEL-BELL	Hôpital Adjel Bellatrach (unverified)	B	27	\N	{ed24,general_surgery}	0101000020E61000009E7B0F971C77D23FDC63E94317004240	osm-unverified	f
N-EPH-HOPITAL-IBN-ZOHR	Hôpital Ibn Zohr (unverified)	B	24	\N	{ed24,general_surgery}	0101000020E61000006631B1F9B8B61D402C4833164D3B4240	osm-unverified	f
N-EPH-HOPITAL-DE-KHAROUB	Hôpital de Kharouba (unverified)	B	27	\N	{ed24,general_surgery}	0101000020E610000016FBCBEEC9C3BA3FDE3CD52137FB4140	osm-unverified	f
N-EPH-HOPITAL-ERNESTO-CH	Hôpital Ernesto Che Guevara (unverified)	B	27	\N	{ed24,general_surgery}	0101000020E61000005E6397A8DE1AB83F48C49448A2F74140	osm-unverified	f
N-EPH-EPH-SIDI-AISSA	EPH Sidi Aissa (unverified)	B	28	\N	{ed24,general_surgery}	0101000020E61000006B9A779CA2230E403CF71E2E39F24140	osm-unverified	f
N-EPH-FACILITY-536	مستشفى عسلي محمد (unverified)	B	28	\N	{ed24,general_surgery}	0101000020E61000007862D68BA19C10406F2F698CD66D4140	osm-unverified	f
N-EPH-HOPITAL-BACHIR-REZ	Hôpital Bachir Rezig (unverified)	B	28	\N	{ed24,general_surgery}	0101000020E61000003108AC1C5AA41040282CF180B2994140	osm-unverified	f
N-EPH-HOPITAL-EZZAHRAOUI	Hôpital Ezzahraoui (unverified)	B	28	\N	{ed24,general_surgery}	0101000020E61000006C9560713833124088D7F50B76DB4140	osm-unverified	f
N-EPH-HOPITAL-SELMANE	Hopital Selmane (unverified)	B	28	\N	{ed24,general_surgery}	0101000020E6100000F8C264AA60141340B13385CE6BD84140	osm-unverified	f
N-EPH-HOPITAL-AMAMRA-HBI	hôpital AMAMRA HBIB (unverified)	B	29	\N	{ed24,general_surgery}	0101000020E61000002D431CEBE236E63F6C04E275FDBA4140	osm-unverified	f
N-EPH-HOPITAL-DAHAOUA-DA	Hôpital Dahaoua Dahou (unverified)	B	29	\N	{ed24,general_surgery}	0101000020E610000025E99AC937DBB43FD673D2FBC6CB4140	osm-unverified	f
N-EPH-HOPITAL-DE-BOUHANI	Hôpital de Bouhanifia (unverified)	B	29	\N	{ed24,general_surgery}	0101000020E61000004F3BFC3559A3AEBFE674594C6CA64140	osm-unverified	f
N-EPH-HOPITAL-DE-GHRISS	Hôpital de Ghriss (unverified)	B	29	\N	{ed24,general_surgery}	0101000020E6100000BD00FBE8D495C33F9DF4BEF1B59F4140	osm-unverified	f
N-EPH-HOPITAL-DE-TIGHENN	Hôpital de Tighennif (unverified)	B	29	\N	{ed24,general_surgery}	0101000020E6100000E8DEC325C79DD43F8B54185B08B64140	osm-unverified	f
N-EPH-HOPITAL-MESLEM-TAY	Hôpital Meslem Tayeb (unverified)	B	29	\N	{ed24,general_surgery}	0101000020E610000011AAD4EC8156C43F73BA2C2636B34140	osm-unverified	f
N-EPH-HOPITAL-YESSAAD-KH	Hôpital Yessaad Khaled (unverified)	B	29	\N	{ed24,general_surgery}	0101000020E61000000820B58993FBC13F744694F606B34140	osm-unverified	f
N-CHU-OUARGLA-BOUDIAF	CHU Mohamed Boudiaf (Ouargla) (unverified)	A	30	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E61000001D5A643BDF4F15404E62105839F43F40	osm-unverified	f
N-EPH-HOPITAL-EL-ALLIA	Hôpital El Allia (unverified)	B	30	\N	{ed24,general_surgery}	0101000020E6100000FA7E6ABC74B3154022AB5B3D27594040	osm-unverified	f
N-EPH-HOPITAL-HASSI-MESS	Hôpital Hassi Messaoud (unverified)	B	30	\N	{ed24,general_surgery}	0101000020E6100000FCFB8C0B074218408D28ED0DBEB03F40	osm-unverified	f
N-EPH-HOPITAL-DE-TAOURA	Hôpital de Taoura (unverified)	B	41	\N	{ed24,general_surgery}	0101000020E6100000520ABABDA411204021EA3E00A9154240	osm-unverified	f
N-CHU-ORAN-BENZERDJEB	CHU Dr Benzerdjeb (Oran Plateau) (unverified)	A	31	+213555000203	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics,burns}	0101000020E61000004F5DF92CCF83E4BF70B1A206D3D84140	osm-unverified	f
N-EHU-ORAN-USTO	EHU 1er Novembre 1954 (Oran USTO) (unverified)	A	31	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics,burns}	0101000020E6100000A0E062450DA6E2BF28B8585183D94140	osm-unverified	f
N-EPH-AIN-EL-TURCK	EPH Medjbeur Tami (Ain El Turck) (unverified)	B	31	\N	{ed24,general_surgery}	0101000020E6100000D578E9263108E8BFE5D022DBF9DE4140	osm-unverified	f
N-EPH-EL-MOHGOUN	EPH El Mohgoun (Arzew) (unverified)	B	31	\N	{ed24,general_surgery}	0101000020E61000007B14AE47E17AD4BF5C8FC2F528EC4140	osm-unverified	f
N-EPH-EPH-AKID-OTHMANE	EPH Akid Othmane (unverified)	B	31	\N	{ed24,general_surgery}	0101000020E6100000D8648D7A8846E8BFC9C859D8D3DE4140	osm-unverified	f
N-EPH-HOPITAL-DR-MED-SEG	Hôpital Dr. Med Seghir Nekkache (unverified)	B	31	\N	{ed24,general_surgery}	0101000020E61000001366DAFE9595D6BF4BC8073D9BE94140	osm-unverified	f
N-EPH-HOPITAL-MEDJBER-TA	Hôpital Medjber Tami (unverified)	B	31	\N	{ed24,general_surgery}	0101000020E6100000C3B645990D32E8BF115322895EDE4140	osm-unverified	f
N-EPH-FACILITY-479	مستشفى قاضي محمد (unverified)	B	32	\N	{ed24,general_surgery}	0101000020E6100000BF654E97C5C4B63F54742497FF044140	osm-unverified	f
N-EPH-HOPITAL-120-LITS	HOPITAL 120 LITS (unverified)	B	33	\N	{ed24,general_surgery}	0101000020E61000007B832F4CA6FA2040C095ECD808843A40	osm-unverified	f
N-EPH-HOPITAL-WANTIMIDHI	Hopital Wantimidhi (unverified)	B	33	\N	{ed24,general_surgery}	0101000020E61000003546EBA86AF220409D465A2A6F7F3A40	osm-unverified	f
N-EPH-HOPITAL-BOUZIDI-LA	Hôpital Bouzidi Lakhdar (unverified)	B	34	\N	{ed24,general_surgery}	0101000020E61000001366DAFE951513406440F67AF7074240	osm-unverified	f
N-EPH-HOPITAL-DE-MEDJANA	Hôpital de Medjana (unverified)	B	34	\N	{ed24,general_surgery}	0101000020E61000005F0CE544BBAA124029AE2AFBAE104240	osm-unverified	f
N-EPH-HOPITAL-MOUHAMMED-	Hôpital Mouhammed Bennani (unverified)	B	34	\N	{ed24,general_surgery}	0101000020E610000029D027F2242914400E4FAF9465F84140	osm-unverified	f
N-EPH-BOUMERDES	EPH de Boumerdes (unverified)	B	35	\N	{ed24,general_surgery}	0101000020E610000037894160E5D00B401B2FDD2406614240	osm-unverified	f
N-EPH-DELLYS	EPH Mohamed Bouremani (Dellys) (unverified)	B	35	\N	{ed24,general_surgery}	0101000020E61000009A081B9E5E290F40E8D9ACFA5C754240	osm-unverified	f
N-EPH-HOSPITAL-CHABET-EL	Hospital chabet el ameur (unverified)	B	35	\N	{ed24,general_surgery}	0101000020E6100000EACF7EA4888C0D40D36A48DC63514240	osm-unverified	f
N-EPH-THENIA	EPH de Thenia (unverified)	B	35	\N	{ed24,general_surgery}	0101000020E6100000DBF97E6ABC740C40B0726891ED5C4240	osm-unverified	f
N-EPH-EPH-BOUZID-AMMAR-E	EPH Bouzid Ammar El Kala (unverified)	B	36	\N	{ed24,general_surgery}	0101000020E6100000C2340C1F11E32040ADA3AA09A2724240	osm-unverified	f
N-EPH-HOPITAL-BOUTELDJA	Hôpital bouteldja (unverified)	B	36	\N	{ed24,general_surgery}	0101000020E6100000C0B2D2A4146420404C4F58E201654240	osm-unverified	f
N-EPH-HOPITAL-D-EL-TARF	Hôpital d'El Tarf (unverified)	B	36	\N	{ed24,general_surgery}	0101000020E610000012A5BDC117A620405227A089B0614240	osm-unverified	f
N-EPH-HOPITAL-DE-BESBES	Hôpital de Besbes (unverified)	B	36	\N	{ed24,general_surgery}	0101000020E610000030BB270F0B551F4067D5E76A2B5A4240	osm-unverified	f
N-EPH-HOPITAL-MOHAMED-BO-1	Hopital Mohamed BOUDIAF (unverified)	B	36	\N	{ed24,general_surgery}	0101000020E6100000328FFCC1C0332040304CA60A46414240	osm-unverified	f
N-EPH-FACILITY-246	مستشفى دائرة التفاريتي (unverified)	B	37	\N	{ed24,general_surgery}	0101000020E61000005AF5B9DA8A5D1FC0F5108DEE207E3B40	osm-unverified	f
N-EPH-FACILITY-248	مستشفى دائرة أمهيريز (unverified)	B	37	\N	{ed24,general_surgery}	0101000020E61000008AABCABE2B621FC0B0E600C11C7D3B40	osm-unverified	f
N-EPH-HOPITAL-LAAYOUNE	Hôpital Laâyoune (unverified)	B	37	\N	{ed24,general_surgery}	0101000020E610000084640113B80520C0DFC325C79DBA3B40	osm-unverified	f
N-EPH-HOPITAL-MIXTE-SI-L	Hôpital mixte Si Lhaouess (unverified)	B	37	\N	{ed24,general_surgery}	0101000020E6100000B9A5D590B84720C086200725CCAC3B40	osm-unverified	f
N-EPH-HOSPITAL-DE-AUSSER	Hospital de Aussered (unverified)	B	37	\N	{ed24,general_surgery}	0101000020E61000001EA7E8482E7F1FC07862D68BA19C3B40	osm-unverified	f
N-EPH-EPH-THENIET-EL-HAD	EPH Theniet El Had (unverified)	B	38	\N	{ed24,general_surgery}	0101000020E61000002A8C2D0439280040959F54FB74F04140	osm-unverified	f
N-EPH-HOPITAL-DE-BORDJ-B	Hôpital de Bordj Bou Naâma (unverified)	B	38	\N	{ed24,general_surgery}	0101000020E6100000FA6184F068E3F93FD66EBBD05CEF4140	osm-unverified	f
N-EPH-HOPITAL-CITE-CHOUH	Hôpital Cité Chouhada (unverified)	B	39	\N	{ed24,general_surgery}	0101000020E610000005C078060D7D1B4024624A24D1AB4040	osm-unverified	f
N-EPH-HOPITAL-COMMUNAL-B	Hôpital communal Bachir Bilal (unverified)	B	39	\N	{ed24,general_surgery}	0101000020E6100000EFFE78AF5A991B402B8716D9CEA74040	osm-unverified	f
N-EPH-HOPITAL-DE-ROBBAH	Hôpital de Robbah (unverified)	B	39	\N	{ed24,general_surgery}	0101000020E61000008CF337A110A11B40F8A57EDE54A44040	osm-unverified	f
N-EPH-HOPITAL-GUEMAR	hôpital guemar (unverified)	B	39	\N	{ed24,general_surgery}	0101000020E61000003411363CBD321B40DE3CD52137BF4040	osm-unverified	f
N-EPH-HOPITAL-HEZLA-MOHA	Hôpital Hezla Mohamed Ben Salem (unverified)	B	39	\N	{ed24,general_surgery}	0101000020E61000008C101E6D1CB11B4073F4F8BD4DCB4040	osm-unverified	f
N-EPH-HOPITAL-KOUININE	Hôpital Kouinine (unverified)	B	39	\N	{ed24,general_surgery}	0101000020E6100000205ED72FD84D1B402B306475ABB34040	osm-unverified	f
N-EPH-HOPITAL-REGUIBA	Hôpital Reguiba (unverified)	B	39	\N	{ed24,general_surgery}	0101000020E61000005C035B2558DC1A400EBE30992AC84040	osm-unverified	f
N-EPH-EPH-AHMED-BEN-BELL	EPH Ahmed Ben Bella (unverified)	B	40	\N	{ed24,general_surgery}	0101000020E610000060AB048BC3791C40041C42959AB94140	osm-unverified	f
N-EPH-HOPITAL-ALI-BOU-SE	Hôpital Ali Bou Sehaba (unverified)	B	40	\N	{ed24,general_surgery}	0101000020E61000007DE882FA96991C404F3BFC3559B74140	osm-unverified	f
N-EPH-HOPITAL-DE-ZOUI	Hôpital de Zoui (unverified)	B	40	\N	{ed24,general_surgery}	0101000020E6100000234A7B832F6C1D40B003E78C28A54140	osm-unverified	f
N-EPH-HOPITAL-HIHI-ABDEL	Hôpital Hihi Abdelmadjid (unverified)	B	40	\N	{ed24,general_surgery}	0101000020E6100000211FF46C56BD1B405F46B1DCD2BE4140	osm-unverified	f
N-EPH-HOPITAL-IBN-ROCHD	Hôpital Ibn Rochd (unverified)	B	41	\N	{ed24,general_surgery}	0101000020E610000090662C9ACECE1F40520ABABDA4214240	osm-unverified	f
N-EPH-HOPITAL-REGIONAL-D	Hôpital régional de Souk-ahras (unverified)	B	41	\N	{ed24,general_surgery}	0101000020E6100000CF83BBB376DB1F40325A475513244240	osm-unverified	f
N-EPH-HADJOUT	EPH de Hadjout (unverified)	B	42	\N	{ed24,general_surgery}	0101000020E6100000E7FBA9F1D24D03406F1283C0CA414240	osm-unverified	f
N-EPH-HOPITAL-DE-HADJOUT	Hôpital de Hadjout (unverified)	B	42	\N	{ed24,general_surgery}	0101000020E6100000B1F9B836544C03401AC05B2041414240	osm-unverified	f
N-EPH-HOPITAL-DE-TIPAZA	Hôpital de Tipaza (unverified)	B	42	\N	{ed24,general_surgery}	0101000020E6100000DF89592F86B203406C3EAE0D154B4240	osm-unverified	f
N-EPH-HOPITAL-DR-FARES-Y	Hôpital Dr Fares Yahia (unverified)	B	42	\N	{ed24,general_surgery}	0101000020E6100000CCEEC9C3422D0640378E588B4F514240	osm-unverified	f
N-EPH-HOPITAL-LAKHDAR-BO	Hôpital Lakhdar Bouchemaa (unverified)	B	42	\N	{ed24,general_surgery}	0101000020E6100000BC0512143F06014050C24CDBBF4A4240	osm-unverified	f
N-EPH-HOPITAL-NEUROLOGIE	Hôpital Neurologie cherchell (unverified)	B	42	\N	{ed24,general_surgery}	0101000020E610000049D74CBED9660140CEC7B5A1624C4240	osm-unverified	f
N-EPH-KOLEA	EPH de Kolea (unverified)	B	42	\N	{ed24,general_surgery}	0101000020E6100000BE9F1A2FDD240640A8C64B3789514240	osm-unverified	f
N-EPH-TIPAZA	EPH de Tipaza (unverified)	B	42	\N	{ed24,general_surgery}	0101000020E6100000BA490C022B87034096438B6CE74B4240	osm-unverified	f
N-EPH-120	مستشفى بسعة 120 سرير (unverified)	B	48	\N	{ed24,general_surgery}	0101000020E6100000DE76A1B94EA3F13FDC291DACFFEF4140	osm-unverified	f
N-EPH-FACILITY-457	المستشفى (unverified)	B	48	\N	{ed24,general_surgery}	0101000020E61000006A300DC347C4EB3F73F4F8BD4D0F4240	osm-unverified	f
N-EPH-HOPITAL-DE-BORMADI	Hôpital de Bormadia (unverified)	B	48	\N	{ed24,general_surgery}	0101000020E6100000FF092E56D460E23FD1E80E6267DA4140	osm-unverified	f
N-EPH-HOPITAL-DR-AHMED-F	Hôpital Dr.Ahmed Francis (unverified)	B	48	\N	{ed24,general_surgery}	0101000020E6100000A089B0E1E995ED3F81785DBF60FB4140	osm-unverified	f
N-EPH-EPH-TIMIMOUN-HACHE	EPH Timimoun - Hachemi M'hamed (unverified)	B	49	\N	{ed24,general_surgery}	0101000020E6100000857CD0B359F5CD3F361FD7868A413D40	osm-unverified	f
N-EPH-HOPITAL-SIDI-KHALE	Hôpital Sidi Khaled (unverified)	B	52	\N	{ed24,general_surgery}	0101000020E6100000637FD93D79F81340EB6E9EEA90334140	osm-unverified	f
N-EPH-HOPITAL-IN-GHAR	Hôpital In Ghar (unverified)	B	53	\N	{ed24,general_surgery}	0101000020E6100000747B4963B48EFE3F5DBF60376C1B3B40	osm-unverified	f
N-EPH-EPH-SLIMEN-AMIRAT	EPH Slimen Amirat (unverified)	B	55	\N	{ed24,general_surgery}	0101000020E6100000C993A46B263F18403F575BB1BF8C4040	osm-unverified	f
N-EPH-EPH-TAIBET	EPH Taibet (unverified)	B	55	\N	{ed24,general_surgery}	0101000020E61000002A1DACFF739819407BBDFBE3BD8A4040	osm-unverified	f
N-EPH-NOUVEL-HOPITAL-DE-	Nouvel Hôpital de Touggourt (unverified)	B	55	\N	{ed24,general_surgery}	0101000020E6100000EA3E00A94D3C184050AA7D3A1E8F4040	osm-unverified	f
N-EPH-ANCIEN-HOPITAL	Ancien Hopital (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E6100000A9F6E978CC201240B30C71AC8B3B4240	osm-unverified	f
N-EPH-HOPITAL-AKLOUL-ALI	Hôpital Akloul Ali (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E6100000D105F52D731A12405F0CE544BB3A4240	osm-unverified	f
N-EPH-HOPITAL-BEN-MERAD-	Hôpital Ben Merad El Meki (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E61000004EB4AB90F29313409296CADB11524240	osm-unverified	f
N-EPH-HOPITAL-D-AOKAS	Hôpital d'Aokas (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E610000083C0CAA145F61440FDF675E09C514240	osm-unverified	f
N-EPH-HOPITAL-KHELIL-AMR	Hôpital Khelil Amrane (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E6100000170E846401331440868F882991604240	osm-unverified	f
N-EPH-HOPITAL-ORTHOPEDIQ	Hôpital orthopédique (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E6100000FDA4DAA7E31113405227A089B0554240	osm-unverified	f
N-EPH-HOPITAL-RACHID-BEL	Hôpital Rachid Belhocine (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E61000005D8AABCABECB124011018750A54E4240	osm-unverified	f
N-EPH-HOPITAL-SOUK-EL-TE	Hôpital Souk El Tenine (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E6100000CF49EF1B5F5B15400D897B2C7D504240	osm-unverified	f
N-EPH-HOPITAL-TAOURIRT-I	Hôpital Taourirt Ighil (unverified)	B	6	\N	{ed24,general_surgery}	0101000020E610000061A6ED5F59C91240FDD98F1491594240	osm-unverified	f
N-CHU-BISKRA-SAADANE	CHU Hakim Saadane (Biskra) (unverified)	A	7	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E61000005DFE43FAEDEB1640B30C71AC8B6B4140	osm-unverified	f
N-EPH-FACILITY-168	مستشفى الأمراض العقلية (unverified)	B	7	\N	{ed24,general_surgery}	0101000020E610000056BC9179E4EF1740363CBD5296794140	osm-unverified	f
N-EPH-FUTUR-HOPITAL	futur Hôpital (unverified)	B	7	\N	{ed24,general_surgery}	0101000020E61000004AD235936F961740FCFB8C0B07624140	osm-unverified	f
N-EPH-HOPITAL-DE-FOUGHAL	Hôpital de Foughala (unverified)	B	7	\N	{ed24,general_surgery}	0101000020E610000007EBFF1CE64B1540D36A48DC635D4140	osm-unverified	f
N-EPH-EPH-DJANET	EPH Djanet (unverified)	B	56	\N	{ed24,general_surgery}	0101000020E6100000302AA913D0042340FC8C0B07427A3840	osm-unverified	f
N-EPH-HOPITAL-HOUARI-BOU	Hôpital Houari Boumadiene (kasr El Hirane) (unverified)	B	3	\N	{ed24,general_surgery}	0101000020E61000005CE674594C2C09404FAF946588E34040	osm-unverified	f
N-EPH-HOSPITAL-1	Hospital (unverified)	B	3	\N	{ed24,general_surgery}	0101000020E61000009D853DEDF097034026C79DD2C1D24040	osm-unverified	f
N-EPH-FACILITY-698	المستشفى القديم (unverified)	B	4	\N	{ed24,general_surgery}	0101000020E610000055A4C2D842901D409AEB34D252E54140	osm-unverified	f
N-EPH-FACILITY-771	مستشفى إبن سينا (unverified)	B	4	\N	{ed24,general_surgery}	0101000020E61000003997E2AAB26F1C40C6F99B5088F04140	osm-unverified	f
N-EPH-HOPITAL-MOHAMMED-B	Hôpital Mohammed Boudiaf (unverified)	B	4	\N	{ed24,general_surgery}	0101000020E6100000DE1FEF552B731C40AC90F2936AEF4140	osm-unverified	f
N-EPH-HOPITAL-SLIMANE-AM	Hôpital Slimane Amirat (unverified)	B	4	\N	{ed24,general_surgery}	0101000020E6100000105D50DF32471A40D1915CFE43024240	osm-unverified	f
N-CHU-BATNA-BENFLIS	CHU Benflis Touhami (Batna) (unverified)	A	5	\N	{ed24,general_surgery,trauma_surgery,ct,icu,neurosurgery,pediatrics}	0101000020E61000001973D712F2C11840CE1951DA1BC44140	osm-unverified	f
N-EPH-HOPITAL-ALI-N-MER	Hôpital Ali N'mer (unverified)	B	5	\N	{ed24,general_surgery}	0101000020E6100000DDEA39E97DA317404E9CDCEF50D04140	osm-unverified	f
N-EPH-HOPITAL-D-ARRIS	Hôpital d'Arris (unverified)	B	5	\N	{ed24,general_surgery}	0101000020E61000001F680586AC6E1940B745990D32A14140	osm-unverified	f
N-EPH-HOPITAL-DE-RAS-EL-	Hôpital de Ras El Aioun (unverified)	B	5	\N	{ed24,general_surgery}	0101000020E61000000D8E9257E7981640F4A62215C6D64140	osm-unverified	f
N-EPH-HOPITAL-DE-SERIANA	Hôpital de Seriana (unverified)	B	5	\N	{ed24,general_surgery}	0101000020E610000005C078060DBD18407172BF4351D84140	osm-unverified	f
N-EPH-HOPITAL-ZIZA-MASSI	Hopital Ziza Massika (unverified)	B	5	\N	{ed24,general_surgery}	0101000020E61000000B293FA9F6A917402254A9D903D14140	osm-unverified	f
N-EPH-SANATORIUM-EPH-BAT	Sanatorium EPH Batna (unverified)	B	5	\N	{ed24,general_surgery}	0101000020E610000097FF907EFBBA184033164D6727C74140	osm-unverified	f
N-EPH-L-HOPITAL-LOCAL	L'hôpital local (unverified)	B	56	\N	{ed24,general_surgery}	0101000020E61000002B8716D9CEF72240BDA94885B18D3840	osm-unverified	f
N-EPH-HOPITAL-MEGHAIER	Hôpital Meghaier (unverified)	B	57	\N	{ed24,general_surgery}	0101000020E61000006B9A779CA2A31740CBF8F71917FA4040	osm-unverified	f
N-EPH-HOPITAL-COLONEL-MO	Hôpital Colonel Mohamed Chaabani (unverified)	B	58	\N	{ed24,general_surgery}	0101000020E610000012C2A38D231607408C15359886993E40	osm-unverified	f
N-EPH-HOPITAL-SIDI-BOUAB	Hôpital Sidi Bouabida (unverified)	B	44	\N	{ed24,general_surgery}	0101000020E61000004D2D5BEB8B84FB3F5305A3923A1D4240	osm-unverified	f
N-EPH-EPH-FRERES-CHENAFA	EPH Frères Chenafa (unverified)	B	45	\N	{ed24,general_surgery}	0101000020E6100000E3AAB2EF8AE0D1BF4FAF946588C34040	osm-unverified	f
N-EPH-HOPITAL-AHMED-MEDE	Hôpital Ahmed Medeghri مستشفى أحمد مدغري (unverified)	B	46	\N	{ed24,general_surgery}	0101000020E61000008577B988EF44F2BFB537F8C264A64140	osm-unverified	f
N-EPH-HOPITAL-DE-BENI-SA	Hôpital de Beni Saf (unverified)	B	46	\N	{ed24,general_surgery}	0101000020E61000004E0B5EF41524F6BF97395D1613A74140	osm-unverified	f
N-EPH-HOPITAL-DOCTEUR-BE	Hôpital Docteur Benzarjeb (unverified)	B	46	\N	{ed24,general_surgery}	0101000020E61000001EFE9AAC510FF2BF7E52EDD3F1A44140	osm-unverified	f
N-EPH-HOPITAL-18-FEVRIER	Hôpital 18 fevrier (unverified)	B	47	\N	{ed24,general_surgery}	0101000020E61000003A92CB7F48FF0C407D0569C6A2214040	osm-unverified	f
N-EPH-HOPITAL-BOUHOUN-MO	Hôpital Bouhoun moussa (unverified)	B	47	\N	{ed24,general_surgery}	0101000020E61000008104C58F31F70D40444C89247A6D4040	osm-unverified	f
N-EPH-HOPITAL-D-EL-ATTEU	Hôpital d'El Atteuf (unverified)	B	47	\N	{ed24,general_surgery}	0101000020E61000004E62105839F40D403602F1BA7E3D4040	osm-unverified	f
N-EPH-HOPITAL-DE-GHARDAI	Hôpital de Ghardaïa (unverified)	B	47	\N	{ed24,general_surgery}	0101000020E61000003AE97DE36B8F0D40111E6D1CB13E4040	osm-unverified	f
N-EPH-HOPITAL-DE-ZELFANA	Hôpital de Zelfana (unverified)	B	47	\N	{ed24,general_surgery}	0101000020E610000048F949B54FE71040C1FF56B263334040	osm-unverified	f
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incidents (id, status, band, nsi, conf, location, plus_code, crashed_at, first_channel, merged_count, assigned_unit, hospital_id, wilaya_code, created_at, updated_at, band_override) FROM stdin;
\.


--
-- Data for Name: prealerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prealerts (id, incident_id, hospital_id, channel, body, sent_at, acked_at, acked_by) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (user_id, role, hospital_id, display_name) FROM stdin;
e27c9f23-9378-4e79-b0c5-a8d5f18bec5d	dispatcher	\N	Dispatcher (demo)
6af50c9d-1726-4001-816d-7e147759df0f	hospital	N-CHU-BLIDA-FRANTZ-FANON	Hospital A ED (demo)
aaae5d54-1ef1-46f4-a736-f97845a36c6f	hospital	N-EPH-BLIDA-IBN-ROCHD	Hospital B ED (demo)
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reports (id, incident_id, client_id, channel, source, raw, parsed, parse_error, sender_hash, received_at) FROM stdin;
\.


--
-- Data for Name: sms_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_outbox (id, to_number, body, purpose, incident_id, status, error, created_at, sent_at) FROM stdin;
\.


--
-- Name: audit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_events_id_seq', 1, true);


--
-- Name: assessments assessments_incident_id_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessments
    ADD CONSTRAINT assessments_incident_id_version_key UNIQUE (incident_id, version);


--
-- Name: assessments assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessments
    ADD CONSTRAINT assessments_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: eta_cache eta_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eta_cache
    ADD CONSTRAINT eta_cache_pkey PRIMARY KEY (origin_key, hospital_id);


--
-- Name: hospital_status hospital_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hospital_status
    ADD CONSTRAINT hospital_status_pkey PRIMARY KEY (hospital_id, set_at);


--
-- Name: hospitals hospitals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hospitals
    ADD CONSTRAINT hospitals_pkey PRIMARY KEY (id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: prealerts prealerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prealerts
    ADD CONSTRAINT prealerts_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (user_id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: sms_outbox sms_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_outbox
    ADD CONSTRAINT sms_outbox_pkey PRIMARY KEY (id);


--
-- Name: audit_events_incident_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_events_incident_idx ON public.audit_events USING btree (incident_id, at);


--
-- Name: hospitals_location_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hospitals_location_idx ON public.hospitals USING gist (location);


--
-- Name: incidents_crashed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incidents_crashed_idx ON public.incidents USING btree (crashed_at);


--
-- Name: incidents_location_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incidents_location_idx ON public.incidents USING gist (location);


--
-- Name: incidents_status_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incidents_status_created_idx ON public.incidents USING btree (status, created_at DESC);


--
-- Name: prealerts_hospital_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX prealerts_hospital_idx ON public.prealerts USING btree (hospital_id, sent_at DESC);


--
-- Name: prealerts_incident_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX prealerts_incident_idx ON public.prealerts USING btree (incident_id);


--
-- Name: reports_client_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reports_client_idx ON public.reports USING btree (client_id);


--
-- Name: reports_idempotent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX reports_idempotent_idx ON public.reports USING btree (client_id, channel, md5(raw)) WHERE (client_id IS NOT NULL);


--
-- Name: reports_incident_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reports_incident_idx ON public.reports USING btree (incident_id, received_at);


--
-- Name: reports_unparsed_idempotent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX reports_unparsed_idempotent_idx ON public.reports USING btree (channel, md5(raw), COALESCE(sender_hash, ''::text)) WHERE (client_id IS NULL);


--
-- Name: reports_unparsed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reports_unparsed_idx ON public.reports USING btree (received_at DESC) WHERE (parse_error IS NOT NULL);


--
-- Name: audit_events audit_events_no_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_events_no_update BEFORE DELETE OR UPDATE ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.audit_events_immutable();


--
-- Name: incidents incidents_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER incidents_touch BEFORE UPDATE ON public.incidents FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: assessments assessments_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessments
    ADD CONSTRAINT assessments_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id) ON DELETE CASCADE;


--
-- Name: eta_cache eta_cache_hospital_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eta_cache
    ADD CONSTRAINT eta_cache_hospital_id_fkey FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id) ON DELETE CASCADE;


--
-- Name: hospital_status hospital_status_hospital_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hospital_status
    ADD CONSTRAINT hospital_status_hospital_id_fkey FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id) ON DELETE CASCADE;


--
-- Name: incidents incidents_hospital_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_hospital_id_fkey FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id);


--
-- Name: prealerts prealerts_hospital_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prealerts
    ADD CONSTRAINT prealerts_hospital_id_fkey FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id);


--
-- Name: prealerts prealerts_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prealerts
    ADD CONSTRAINT prealerts_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_hospital_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_hospital_fk FOREIGN KEY (hospital_id) REFERENCES public.hospitals(id) ON DELETE SET NULL;


--
-- Name: profiles profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: reports reports_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id) ON DELETE CASCADE;


--
-- Name: assessments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;

--
-- Name: assessments dispatch read assessments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "dispatch read assessments" ON public.assessments FOR SELECT TO authenticated USING ((public.current_role_name() = ANY (ARRAY['dispatcher'::text, 'admin'::text])));


--
-- Name: audit_events dispatch read audit; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "dispatch read audit" ON public.audit_events FOR SELECT TO authenticated USING ((public.current_role_name() = ANY (ARRAY['dispatcher'::text, 'admin'::text])));


--
-- Name: incidents dispatch read incidents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "dispatch read incidents" ON public.incidents FOR SELECT TO authenticated USING ((public.current_role_name() = ANY (ARRAY['dispatcher'::text, 'admin'::text])));


--
-- Name: prealerts dispatch read prealerts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "dispatch read prealerts" ON public.prealerts FOR SELECT TO authenticated USING ((public.current_role_name() = ANY (ARRAY['dispatcher'::text, 'admin'::text])));


--
-- Name: eta_cache; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eta_cache ENABLE ROW LEVEL SECURITY;

--
-- Name: prealerts hospital reads own prealerts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "hospital reads own prealerts" ON public.prealerts FOR SELECT TO authenticated USING (((public.current_role_name() = 'hospital'::text) AND (hospital_id = public.current_hospital_id())));


--
-- Name: assessments hospital reads pre-alerted assessments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "hospital reads pre-alerted assessments" ON public.assessments FOR SELECT TO authenticated USING (((public.current_role_name() = 'hospital'::text) AND (EXISTS ( SELECT 1
   FROM public.prealerts p
  WHERE ((p.incident_id = assessments.incident_id) AND (p.hospital_id = public.current_hospital_id()))))));


--
-- Name: incidents hospital reads pre-alerted incidents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "hospital reads pre-alerted incidents" ON public.incidents FOR SELECT TO authenticated USING (((public.current_role_name() = 'hospital'::text) AND (EXISTS ( SELECT 1
   FROM public.prealerts p
  WHERE ((p.incident_id = incidents.id) AND (p.hospital_id = public.current_hospital_id()))))));


--
-- Name: hospital_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hospital_status ENABLE ROW LEVEL SECURITY;

--
-- Name: hospitals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hospitals ENABLE ROW LEVEL SECURITY;

--
-- Name: incidents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.incidents ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "own profile" ON public.profiles FOR SELECT TO authenticated USING ((user_id = auth.uid()));


--
-- Name: prealerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.prealerts ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

--
-- Name: sms_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sms_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: hospital_status staff read hospital_status; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "staff read hospital_status" ON public.hospital_status FOR SELECT TO authenticated USING ((public.current_role_name() IS NOT NULL));


--
-- Name: hospitals staff read hospitals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "staff read hospitals" ON public.hospitals FOR SELECT TO authenticated USING ((public.current_role_name() IS NOT NULL));


--
-- Name: reports staff read reports; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "staff read reports" ON public.reports FOR SELECT TO authenticated USING ((public.current_role_name() = ANY (ARRAY['dispatcher'::text, 'admin'::text])));


--
-- PostgreSQL database dump complete
--

\unrestrict ogVEg6vXJndfe8Owwbz0wM6r844esHe48MF6r4hIJkDVDB1Gy9enbuB4m0up7GV

